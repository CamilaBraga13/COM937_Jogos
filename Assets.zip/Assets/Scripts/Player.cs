using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

public class Player : MonoBehaviour
{

    Rigidbody2D _playerRb;
    Vector2 mov;


    // Start is called before the first frame update
    void Start()
    {
        _playerRb = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        Movimentacao();
    }


    void Movimentacao(){
        _playerRb.velocity = mov;
    }



    void OnMove(InputValue inputValue) {
        // print("Movimentação!");
        mov = inputValue.Get<Vector2>();
        // print($"X: {movHor.x} Y:{movHor.y}");
    }

}
